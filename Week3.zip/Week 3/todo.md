Week 3: To Do

[] Servers
[] Hosting
[] Domain Names
[] FTP/Filezilla/WinSCP
[] CMS
[] Frameworks
[] Single Page Templates